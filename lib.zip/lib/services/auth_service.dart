import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/user_model.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // Get current user
  User? get currentUser => _auth.currentUser;

  // Stream of auth changes
  Stream<User?> get authStateChanges => _auth.authStateChanges();

  // Sign up with email and password
  Future<UserModel?> signUpWithEmail({
    required String email,
    required String password,
    required String name,
    required String phone,
    required String role,
  }) async {
    try {
      final result = await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );

      final user = result.user;
      if (user != null) {
        final newUser = UserModel(
          uid: user.uid,
          email: email,
          phone: phone,
          name: name,
          role: role,
        );

        await _firestore.collection('users').doc(user.uid).set(newUser.toMap());
        return newUser;
      }
      return null;
    } on FirebaseAuthException {
      rethrow;
    } catch (e) {
      rethrow;
    }
  }

  // Sign in with email and password and return full UserModel (from Firestore or created)
  Future<UserModel?> signInWithEmail({
    required String email,
    required String password,
  }) async {
    try {
      final result = await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );

      final user = result.user;
      if (user == null) return null;

      // Try to load Firestore profile; if missing, create a minimal profile so app can continue
      final existing = await getUserData(user.uid);
      if (existing != null) return existing;

      // If no document exists, create a default profile so the app will navigate
      final defaultModel = UserModel(
        uid: user.uid,
        email: user.email ?? email,
        name: user.displayName ?? '',
        phone: user.phoneNumber ?? '',
        role: 'passenger', // default role
      );

      await _firestore.collection('users').doc(user.uid).set(defaultModel.toMap());
      return defaultModel;
    } on FirebaseAuthException {
      rethrow;
    } catch (e) {
      rethrow;
    }
  }

  // Get user data from Firestore
  Future<UserModel?> getUserData(String uid) async {
    try {
      final doc = await _firestore.collection('users').doc(uid).get();
      if (!doc.exists) return null;
      final data = doc.data();
      if (data is Map<String, dynamic>) {
        // Adjust this to match your UserModel.fromMap signature.
        // Common: UserModel.fromMap(Map<String,dynamic> map, String uid)
        return UserModel.fromMap(data, uid);
      }
      return null;
    } catch (e) {
      // return null so callers can handle
      print('AuthService.getUserData error: $e');
      return null;
    }
  }

  // Sign out
  Future<void> signOut() async {
    await _auth.signOut();
  }

  // Update user profile
  Future<void> updateUserProfile({
    required String uid,
    String? name,
    String? phone,
  }) async {
    final updates = <String, dynamic>{};
    if (name != null) updates['name'] = name;
    if (phone != null) updates['phone'] = phone;
    if (updates.isEmpty) return;
    await _firestore.collection('users').doc(uid).update(updates);
  }

  // --- New Feature: Change Password ---
  Future<void> changePassword({
    required String currentPassword,
    required String newPassword,
  }) async {
    final user = _auth.currentUser;

    if (user == null) {
      throw Exception('No authenticated user found.');
    }

    if (user.email == null) {
      throw Exception('Password cannot be changed for a user without an email.');
    }

    try {
      // 1. Re-authenticate the user with their current password.
      // This is a security requirement for sensitive operations like changing the password.
      final cred = EmailAuthProvider.credential(
        email: user.email!,
        password: currentPassword,
      );

      await user.reauthenticateWithCredential(cred);

      // 2. If re-authentication succeeds, update the password.
      await user.updatePassword(newPassword);

      // Note: We don't need to update Firestore here, as the password is a Firebase Auth property.

    } on FirebaseAuthException catch (e) {
      // Re-throw specific Firebase auth errors (e.g., 'wrong-password')
      rethrow;
    } catch (e) {
      // Re-throw any other errors
      rethrow;
    }
  }
}