import 'package:cloud_firestore/cloud_firestore.dart';

class RideModel {
  final String rideId;
  final String driverId;
  final String driverName;
  final String driverPhone;
  final String origin;
  final String destination;
  final DateTime dateTime;
  final int totalSeats;
  final int availableSeats;
  final String status; // 'active', 'completed', 'cancelled'

  RideModel({
    required this.rideId,
    required this.driverId,
    required this.driverName,
    required this.driverPhone,
    required this.origin,
    required this.destination,
    required this.dateTime,
    required this.totalSeats,
    required this.availableSeats,
    this.status = 'active',
  });

  Map<String, dynamic> toMap() {
    return {
      'rideId': rideId,
      'driverId': driverId,
      'driverName': driverName,
      'driverPhone': driverPhone,
      'origin': origin,
      'destination': destination,
      'dateTime': Timestamp.fromDate(dateTime),
      'totalSeats': totalSeats,
      'availableSeats': availableSeats,
      'status': status,
    };
  }

  factory RideModel.fromMap(Map<String, dynamic> map) {
    return RideModel(
      rideId: map['rideId'] ?? '',
      driverId: map['driverId'] ?? '',
      driverName: map['driverName'] ?? '',
      driverPhone: map['driverPhone'] ?? '',
      origin: map['origin'] ?? '',
      destination: map['destination'] ?? '',
      dateTime: (map['dateTime'] as Timestamp).toDate(),
      totalSeats: map['totalSeats'] ?? 0,
      availableSeats: map['availableSeats'] ?? 0,
      status: map['status'] ?? 'active',
    );
  }

  RideModel copyWith({
    String? rideId,
    String? driverId,
    String? driverName,
    String? driverPhone,
    String? origin,
    String? destination,
    DateTime? dateTime,
    int? totalSeats,
    int? availableSeats,
    String? status,
  }) {
    return RideModel(
      rideId: rideId ?? this.rideId,
      driverId: driverId ?? this.driverId,
      driverName: driverName ?? this.driverName,
      driverPhone: driverPhone ?? this.driverPhone,
      origin: origin ?? this.origin,
      destination: destination ?? this.destination,
      dateTime: dateTime ?? this.dateTime,
      totalSeats: totalSeats ?? this.totalSeats,
      availableSeats: availableSeats ?? this.availableSeats,
      status: status ?? this.status,
    );
  }
}