import 'package:cloud_firestore/cloud_firestore.dart';

class BookingModel {
  final String bookingId;
  final String rideId;
  final String passengerId;
  final String passengerName;
  final String passengerPhone;
  final int seatsBooked;
  final DateTime bookingTime;
  final String status; // 'confirmed', 'cancelled'

  BookingModel({
    required this.bookingId,
    required this.rideId,
    required this.passengerId,
    required this.passengerName,
    required this.passengerPhone,
    required this.seatsBooked,
    required this.bookingTime,
    this.status = 'confirmed',
  });

  Map<String, dynamic> toMap() {
    return {
      'bookingId': bookingId,
      'rideId': rideId,
      'passengerId': passengerId,
      'passengerName': passengerName,
      'passengerPhone': passengerPhone,
      'seatsBooked': seatsBooked,
      'bookingTime': Timestamp.fromDate(bookingTime),
      'status': status,
    };
  }

  factory BookingModel.fromMap(Map<String, dynamic> map) {
    return BookingModel(
      bookingId: map['bookingId'] ?? '',
      rideId: map['rideId'] ?? '',
      passengerId: map['passengerId'] ?? '',
      passengerName: map['passengerName'] ?? '',
      passengerPhone: map['passengerPhone'] ?? '',
      seatsBooked: map['seatsBooked'] ?? 1,
      bookingTime: (map['bookingTime'] as Timestamp).toDate(),
      status: map['status'] ?? 'confirmed',
    );
  }

  BookingModel copyWith({
    String? bookingId,
    String? rideId,
    String? passengerId,
    String? passengerName,
    String? passengerPhone,
    int? seatsBooked,
    DateTime? bookingTime,
    String? status,
  }) {
    return BookingModel(
      bookingId: bookingId ?? this.bookingId,
      rideId: rideId ?? this.rideId,
      passengerId: passengerId ?? this.passengerId,
      passengerName: passengerName ?? this.passengerName,
      passengerPhone: passengerPhone ?? this.passengerPhone,
      seatsBooked: seatsBooked ?? this.seatsBooked,
      bookingTime: bookingTime ?? this.bookingTime,
      status: status ?? this.status,
    );
  }
}