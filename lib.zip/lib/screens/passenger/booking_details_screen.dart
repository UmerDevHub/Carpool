import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../models/booking_model.dart'; // Using actual BookingModel import
import '../../models/ride_model.dart';
import '../../services/ride_service.dart';

// --- Removed Placeholder BookingModel Definition ---

class BookingDetailsScreen extends StatefulWidget {
  final BookingModel booking;

  const BookingDetailsScreen({Key? key, required this.booking}) : super(key: key);

  @override
  State<BookingDetailsScreen> createState() => _BookingDetailsScreenState();
}

class _BookingDetailsScreenState extends State<BookingDetailsScreen> {
  final RideService _rideService = RideService();
  RideModel? _ride;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadRideDetails();
  }

  @override
  void dispose() {
    super.dispose();
  }

  Future<void> _loadRideDetails() async {
    try {
      // Assuming getRideById returns the current RideModel, which includes status
      final ride = await _rideService.getRideById(widget.booking.rideId);
      if (mounted) {
        setState(() {
          _ride = ride;
          _isLoading = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
        // In a real app, if the ride is not found (deleted), it's also effectively cancelled
        _showSnackBar('Error loading ride details: Ride may be removed or cancelled.', Colors.red);
      }
    }
  }

  Future<void> _makePhoneCall(String phoneNumber) async {
    final Uri phoneUri = Uri(scheme: 'tel', path: phoneNumber);
    if (await canLaunchUrl(phoneUri)) {
      await launchUrl(phoneUri);
    } else {
      if (mounted) {
        _showSnackBar('Could not launch phone dialer for $phoneNumber', Colors.red);
      }
    }
  }

  Future<void> _cancelBooking() async {
    final theme = Theme.of(context);
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('Cancel Booking'),
        content: const Text('Are you sure you want to cancel this booking? This action cannot be undone.'),
        actionsAlignment: MainAxisAlignment.spaceAround,
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Keep Booking', style: TextStyle(color: theme.colorScheme.primary)),
          ),
          ElevatedButton(
            onPressed: () async {
              Navigator.pop(context); // Dismiss the AlertDialog

              try {
                // This assumes your actual BookingModel uses 'bookingId'
                await _rideService.cancelBooking(
                  widget.booking.bookingId,
                  widget.booking.rideId,
                  widget.booking.seatsBooked,
                );

                if (mounted) {
                  _showSnackBar('Booking cancelled successfully', Colors.green);
                  // Dismiss the BookingDetailsScreen and signal success
                  Navigator.pop(context, true);
                }
              } catch (e) {
                if (mounted) {
                  _showSnackBar('Error cancelling booking: $e', Colors.red);
                }
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red.shade600,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
            ),
            child: const Text('Yes, Cancel'),
          ),
        ],
      ),
    );
  }

  void _showSnackBar(String message, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: color,
        behavior: SnackBarBehavior.floating,
        duration: const Duration(seconds: 3),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    if (_isLoading) {
      return Scaffold(
        appBar: AppBar(title: const Text('Booking Details')),
        body: Center(child: CircularProgressIndicator(color: theme.colorScheme.primary)),
      );
    }

    if (_ride == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Booking Details')),
        body: const Center(
          child: Text('Ride details could not be loaded.'),
        ),
      );
    }

    final dateFormat = DateFormat('EEEE, MMM dd, yyyy');
    final timeFormat = DateFormat('hh:mm a');
    final bookingDateFormat = DateFormat('MMM dd, yyyy - hh:mm a');

    // --- CRITICAL CANCELLATION LOGIC ---
    // 1. Check if the Ride is active
    final bool isRideActive = _ride!.status == 'active';

    // 2. Define the condition under which the user can cancel the booking.
    // This is true ONLY if the booking status is 'confirmed' AND the associated ride is 'active'.
    final bool isCancellable = widget.booking.status == 'confirmed' && isRideActive;

    Color statusColor;
    String statusText;
    IconData statusIcon;

    if (_ride!.status == 'cancelled') {
      // If the ride itself is cancelled (by the driver), display this status.
      statusColor = Colors.red.shade600;
      statusText = 'Ride Cancelled by Driver';
      statusIcon = Icons.report_problem_rounded;
    } else if (_ride!.status == 'completed') {
      // If the ride is completed, display this status.
      statusColor = Colors.blue.shade600;
      statusText = 'Ride Completed Successfully'; // Updated text for clarity
      statusIcon = Icons.done_all_rounded;
    } else if (widget.booking.status == 'cancelled') {
      // If the ride is still active, but the booking status is cancelled (passenger cancelled earlier)
      statusColor = Colors.red.shade600;
      statusText = 'Booking Cancelled (by Passenger)';
      statusIcon = Icons.cancel_rounded;
    }
    else {
      // Confirmed (active ride, confirmed booking)
      statusColor = Colors.green.shade600;
      statusText = 'Booking Confirmed (Ride is Active)'; // Updated text for clarity
      statusIcon = Icons.check_circle_rounded;
    }
    // --------------------------------------


    return Scaffold(
      appBar: AppBar(
        title: const Text('Booking Details'),
        elevation: 0,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.only(bottom: 30),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // --- 1. Status Header ---
            _buildStatusHeader(theme, statusColor, statusIcon, statusText, bookingDateFormat),

            // --- 2. Trip Details Card ---
            Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildSectionTitle(theme, 'Route Overview', Icons.route_rounded),
                  const SizedBox(height: 16),
                  _buildRouteCard(theme, _ride!.origin, _ride!.destination),

                  const SizedBox(height: 32),

                  // --- 3. Time & Seats Information ---
                  _buildSectionTitle(theme, 'Booking Summary', Icons.calendar_month_rounded),
                  const SizedBox(height: 16),
                  _buildSummaryCard(theme, dateFormat, timeFormat, _ride!.dateTime, widget.booking.seatsBooked),

                  const SizedBox(height: 32),

                  // --- 4. Driver Information Card ---
                  _buildSectionTitle(theme, 'Driver Details', Icons.person_pin_circle_rounded),
                  const SizedBox(height: 16),
                  // Pass isDark explicitly as it's used inside the helper
                  _buildDriverCard(theme, _ride!.driverName, _ride!.driverPhone, theme.brightness == Brightness.dark),

                  const SizedBox(height: 40),

                  // --- 5. Cancel Button (Visible only if cancellable) ---
                  if (isCancellable)
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton.icon(
                        onPressed: _cancelBooking,
                        icon: const Icon(Icons.close_rounded),
                        label: const Text('Cancel Booking'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.red.shade50,
                          foregroundColor: Colors.red.shade700,
                          side: BorderSide(color: Colors.red.shade200, width: 1.5),
                          padding: const EdgeInsets.symmetric(vertical: 18),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                          elevation: 0,
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionTitle(ThemeData theme, String title, IconData icon) {
    return Row(
      children: [
        Icon(icon, color: theme.colorScheme.primary, size: 24),
        const SizedBox(width: 10),
        Text(
          title,
          style: theme.textTheme.titleLarge?.copyWith(
            fontWeight: FontWeight.w800,
          ),
        ),
      ],
    );
  }

  Widget _buildStatusHeader(ThemeData theme, Color statusColor, IconData statusIcon, String statusText, DateFormat bookingDateFormat) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 30),
      decoration: BoxDecoration(
        color: statusColor.withOpacity(0.1),
        border: Border(bottom: BorderSide(color: statusColor.withOpacity(0.3))),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: statusColor,
              shape: BoxShape.circle,
            ),
            child: Icon(
              statusIcon,
              color: Colors.white,
              size: 28,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  statusText,
                  style: theme.textTheme.headlineSmall?.copyWith(
                    fontWeight: FontWeight.bold,
                    color: statusColor,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'Booked on ${bookingDateFormat.format(widget.booking.bookingTime)}',
                  style: theme.textTheme.bodyMedium?.copyWith(
                    color: Theme.of(context).textTheme.bodyMedium?.color?.withOpacity(0.7),
                    fontSize: 14,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRouteCard(ThemeData theme, String origin, String destination) {
    final isDark = theme.brightness == Brightness.dark;

    Widget _buildLocationItem({
      required String title,
      required String label,
      required Color color,
      required bool isEnd,
    }) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Column(
                children: [
                  Container(
                    width: 12,
                    height: 12,
                    decoration: BoxDecoration(
                      color: color,
                      shape: BoxShape.circle,
                      border: Border.all(color: color.withOpacity(0.5), width: 2),
                    ),
                  ),
                  if (!isEnd)
                    Container(
                      height: 40,
                      width: 2,
                      color: isDark ? Colors.grey.shade700 : Colors.grey.shade300,
                    ),
                ],
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      label,
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: isDark ? Colors.grey.shade400 : Colors.grey.shade600,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      title,
                      style: theme.textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.w600, // Adjusted font weight for better readability of long titles
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      );
    }

    return Card(
      elevation: 5,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      shadowColor: theme.colorScheme.primary.withOpacity(0.1),
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          children: [
            _buildLocationItem(
              title: origin,
              label: 'Departure Point',
              color: Colors.green.shade500,
              isEnd: false,
            ),
            const SizedBox(height: 8),
            _buildLocationItem(
              title: destination,
              label: 'Arrival Destination',
              color: Colors.red.shade500,
              isEnd: true,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSummaryCard(ThemeData theme, DateFormat dateFormat, DateFormat timeFormat, DateTime dateTime, int seatsBooked) {
    final isDark = theme.brightness == Brightness.dark;

    Widget _buildDetailItem({required IconData icon, required String label, required String value, required Color color}) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, size: 18, color: color),
              const SizedBox(width: 8),
              Text(
                label,
                style: theme.textTheme.bodySmall?.copyWith(
                  color: isDark ? Colors.grey.shade400 : Colors.grey.shade600,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text(
            value,
            style: theme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w700, // Adjusted font weight for better visual balance
            ),
          ),
        ],
      );
    }

    return Card(
      elevation: 5,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      shadowColor: theme.colorScheme.secondary.withOpacity(0.1),
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: IntrinsicHeight(
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              Expanded(
                child: _buildDetailItem(
                  icon: Icons.calendar_today_rounded,
                  label: 'Date',
                  value: dateFormat.format(dateTime),
                  color: theme.colorScheme.primary,
                ),
              ),
              VerticalDivider(
                color: isDark ? Colors.grey.shade700 : Colors.grey.shade300,
                thickness: 1,
                width: 30,
              ),
              Expanded(
                child: _buildDetailItem(
                  icon: Icons.access_time_filled_rounded,
                  label: 'Time',
                  value: timeFormat.format(dateTime),
                  color: theme.colorScheme.primary,
                ),
              ),
              VerticalDivider(
                color: isDark ? Colors.grey.shade700 : Colors.grey.shade300,
                thickness: 1,
                width: 30,
              ),
              Expanded(
                child: _buildDetailItem(
                  icon: Icons.event_seat_rounded,
                  label: 'Seats',
                  value: '$seatsBooked',
                  color: Colors.orange.shade600,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDriverCard(ThemeData theme, String driverName, String driverPhone, bool isDark) {
    return Card(
      elevation: 5,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      shadowColor: theme.colorScheme.primary.withOpacity(0.15),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Row(
          children: [
            CircleAvatar(
              radius: 30,
              backgroundColor: theme.colorScheme.primary.withOpacity(0.2),
              child: Icon(
                Icons.person_rounded,
                size: 32,
                color: theme.colorScheme.primary,
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    driverName,
                    style: theme.textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.w700, // Adjusted from w800 for better balance
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    driverPhone,
                    style: theme.textTheme.bodyLarge?.copyWith( // Increased text size
                      fontWeight: FontWeight.w600, // Made phone number bolder
                      color: isDark ? Colors.grey.shade300 : Colors.grey.shade800, // Increased contrast
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 16),
            ElevatedButton.icon(
              onPressed: () => _makePhoneCall(driverPhone),
              icon: const Icon(Icons.phone_rounded, size: 20),
              label: const Text('Call'),
              style: ElevatedButton.styleFrom(
                backgroundColor: theme.colorScheme.secondary,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                elevation: 4,
                shadowColor: theme.colorScheme.secondary.withOpacity(0.4),
              ),
            ),
          ],
        ),
      ),
    );
  }
}