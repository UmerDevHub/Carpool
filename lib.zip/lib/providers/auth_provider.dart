import 'dart:async';
import 'package:flutter/material.dart';
import '../models/user_model.dart';
import '../services/auth_service.dart';
import '../services/shared_prefs_service.dart';

class AuthProvider extends ChangeNotifier {
  final AuthService _authService = AuthService();

  UserModel? _currentUser;
  bool _isLoading = false;
  String? _errorMessage;
  bool _isAuthenticated = false;

  // Getters
  UserModel? get currentUser => _currentUser;
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;
  bool get isAuthenticated => _isAuthenticated;

  StreamSubscription? _authSub;

  AuthProvider() {
    _init();
  }

  void _init() {
    // Keep listening to Firebase auth changes so provider stays in sync
    _authSub = _authService.authStateChanges.listen((firebaseUser) async {
      if (firebaseUser == null) {
        _currentUser = null;
        _isAuthenticated = false;
        await SharedPrefsService.clearUserSession();
        notifyListeners();
        return;
      }

      _isLoading = true;
      notifyListeners();

      final profile = await _authService.getUserData(firebaseUser.uid);
      if (profile != null) {
        _currentUser = profile;
        _isAuthenticated = true;
        await SharedPrefsService.saveUserSession(
          userId: profile.uid,
          email: profile.email,
          name: profile.name ?? '',
          phone: profile.phone ?? '',
          role: profile.role,
        );
      } else {
        // Create default profile to avoid blocking navigation
        final created = UserModel(
          uid: firebaseUser.uid,
          email: firebaseUser.email ?? '',
          name: firebaseUser.displayName ?? '',
          phone: firebaseUser.phoneNumber ?? '',
          role: 'passenger',
        );
        // Persist created profile
        await _authService.updateUserProfile(uid: created.uid, name: created.name, phone: created.phone);
        _currentUser = created;
        _isAuthenticated = true;
        await SharedPrefsService.saveUserSession(
          userId: created.uid,
          email: created.email,
          name: created.name ?? '',
          phone: created.phone ?? '',
          role: created.role,
        );
      }

      _isLoading = false;
      notifyListeners();
    }, onError: (e) {
      debugPrint('AuthProvider authStateChanges error: $e');
      _isLoading = false;
      _isAuthenticated = false;
      _currentUser = null;
      notifyListeners();
    });
  }

  // Sign in using AuthService which returns a complete UserModel (or null)
  Future<bool> signIn({
    required String email,
    required String password,
  }) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      final userModel = await _authService.signInWithEmail(email: email.trim(), password: password);
      if (userModel != null) {
        _currentUser = userModel;
        _isAuthenticated = true;

        // Save session if remember me is enabled
        if (SharedPrefsService.getRememberMe()) {
          await SharedPrefsService.saveUserSession(
            userId: userModel.uid,
            email: userModel.email,
            name: userModel.name ?? '',
            phone: userModel.phone ?? '',
            role: userModel.role,
          );
        }

        _isLoading = false;
        notifyListeners();
        return true;
      } else {
        _errorMessage = 'Failed to load user profile after sign-in.';
        _isLoading = false;
        notifyListeners();
        return false;
      }
    } catch (e) {
      _isLoading = false;
      _errorMessage = e.toString();
      notifyListeners();
      return false;
    }
  }

  Future<bool> signUp({
    required String email,
    required String password,
    required String name,
    required String phone,
    required String role,
  }) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      final created = await _authService.signUpWithEmail(
        email: email.trim(),
        password: password,
        name: name,
        phone: phone,
        role: role,
      );

      if (created != null) {
        _currentUser = created;
        _isAuthenticated = true;
        _isLoading = false;
        notifyListeners();
        return true;
      }

      _errorMessage = 'Sign up failed.';
      _isLoading = false;
      notifyListeners();
      return false;
    } catch (e) {
      _errorMessage = e.toString();
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  // --- New Feature: Update User Profile (Called by ProfileScreen) ---
  Future<void> updateUser({required String name, String? phone}) async {
    if (_currentUser == null) return;

    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      // 1. Update backend via AuthService
      await _authService.updateUserProfile(
        uid: _currentUser!.uid,
        name: name,
        phone: phone,
      );

      // 2. Update local state
      _currentUser = _currentUser!.copyWith(
        name: name,
        phone: phone,
      );

      // 3. Update Shared Preferences session
      await SharedPrefsService.saveUserSession(
        userId: _currentUser!.uid,
        email: _currentUser!.email,
        name: name,
        phone: phone ?? '',
        role: _currentUser!.role,
      );

      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _errorMessage = 'Failed to update profile: ${e.toString()}';
      _isLoading = false;
      notifyListeners();
    }
  }

  // --- New Feature: Change Password (Called by ProfileScreen) ---
  Future<void> changePassword({
    required String currentPassword,
    required String newPassword,
  }) async {
    if (_currentUser == null) return;

    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      // Call AuthService method to handle re-authentication and password change
      await _authService.changePassword(
        currentPassword: currentPassword,
        newPassword: newPassword,
      );

      _isLoading = false;
      notifyListeners();
    } catch (e) {
      // Catch specific Firebase errors (e.g., wrong current password)
      _errorMessage = 'Password change failed: ${e.toString()}';
      _isLoading = false;
      notifyListeners();
      // Re-throw the error so the UI dialog can catch it and display it.
      rethrow;
    }
  }


  Future<void> signOut() async {
    _isLoading = true;
    notifyListeners();
    await _authService.signOut();
    _isLoading = false;
    _currentUser = null;
    _isAuthenticated = false;
    await SharedPrefsService.clearUserSession();
    notifyListeners();
  }

  @override
  void dispose() {
    _authSub?.cancel();
    super.dispose();
  }

  void clearError() {
    _errorMessage = null;
    notifyListeners();
  }
}